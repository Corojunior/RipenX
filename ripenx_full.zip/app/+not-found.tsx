import { Link } from 'expo-router';
import { SafeAreaView, Text, View } from 'react-native';

export default function NotFound() {
  return (
    <SafeAreaView style={{ flex: 1, alignItems:'center', justifyContent:'center' }}>
      <View>
        <Text style={{ fontSize: 18, marginBottom: 8 }}>Oops! Screen not found.</Text>
        <Link href="/">Go Home</Link>
      </View>
    </SafeAreaView>
  );
}