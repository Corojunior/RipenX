import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  Alert, ActivityIndicator, ScrollView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LogoComponent } from '../../components/LogoComponent';
import { classifyImages } from '../../utils/classifier';
import { saveRunToHistory } from '../../utils/storage';

export default function HomeScreen() {
  const [isProcessing, setIsProcessing] = useState(false);
  const router = useRouter();

  const pickImages = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Please grant permission to access photos');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true,
        quality: 0.8,
        aspect: [1, 1],
      });
      if (!result.canceled && result.assets) {
        setIsProcessing(true);
        const predictions = await classifyImages(result.assets);
        await AsyncStorage.setItem('latestResults', JSON.stringify(predictions));
        await saveRunToHistory(predictions);
        setIsProcessing(false);
        router.push('/results');
      }
    } catch (error) {
      console.error('Error picking images:', error);
      setIsProcessing(false);
      Alert.alert('Error', 'Failed to pick images');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>RipenX</Text>
          <View style={styles.debugBadge}><Text style={styles.debugText}>DEMO</Text></View>
        </View>

        <LogoComponent />

        <Text style={styles.subtitle}>AI based Palm Oil Grading App</Text>

        <View style={styles.infoSection}>
          <Text style={styles.infoText}>Upload single / multiple images to be classified</Text>
          <Text style={styles.modelInfo}>AI Model: InceptionV3 (TFLite)</Text>
        </View>

        <TouchableOpacity style={[styles.pickButton, isProcessing && styles.buttonDisabled]} onPress={pickImages} disabled={isProcessing}>
          <Ionicons name="images" size={24} color="white" style={styles.buttonIcon} />
          <Text style={styles.buttonText}>Pick Images</Text>
        </TouchableOpacity>

        {isProcessing && (
          <View style={styles.processingContainer}>
            <ActivityIndicator size="large" color="#059669" />
            <Text style={styles.processingText}>Processing images...</Text>
          </View>
        )}

        <View style={styles.placeholderSection}>
          <Text style={styles.placeholderText}>No results yet — pick images to classify</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  scrollContent: { flexGrow: 1, alignItems: 'center', paddingHorizontal: 20, paddingTop: 20 },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 30 },
  title: { fontSize: 32, fontWeight: 'bold', color: '#1F2937' },
  debugBadge: { backgroundColor: '#EF4444', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, marginLeft: 12 },
  debugText: { color: 'white', fontSize: 12, fontWeight: 'bold' },
  subtitle: { fontSize: 20, color: '#374151', textAlign: 'center', marginTop: 16, marginBottom: 32 },
  infoSection: { alignItems: 'center', marginBottom: 32 },
  infoText: { fontSize: 16, color: '#6B7280', textAlign: 'center', marginBottom: 8 },
  modelInfo: { fontSize: 14, color: '#374151', fontWeight: '600' },
  pickButton: { backgroundColor: '#059669', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, paddingHorizontal: 32, borderRadius: 12, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, marginBottom: 32 },
  buttonDisabled: { backgroundColor: '#9CA3AF' },
  buttonIcon: { marginRight: 8 },
  buttonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  processingContainer: { alignItems: 'center', marginBottom: 32 },
  processingText: { marginTop: 12, fontSize: 16, color: '#059669' },
  placeholderSection: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  placeholderText: { fontSize: 16, color: '#9CA3AF', textAlign: 'center' },
});