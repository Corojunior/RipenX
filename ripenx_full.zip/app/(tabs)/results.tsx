import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, Image, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import { ProgressBar } from '../../components/ProgressBar';
import { generatePDF } from '../../utils/pdfGenerator';
import type { PredictionResult } from '../../types';

export default function ResultsScreen() {
  const [results, setResults] = useState<PredictionResult[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  useEffect(() => { loadResults(); }, []);

  const loadResults = async () => {
    try {
      const savedResults = await AsyncStorage.getItem('latestResults');
      if (savedResults) setResults(JSON.parse(savedResults));
    } catch (error) {
      console.error('Error loading results:', error);
    } finally { setIsLoading(false); }
  };

  const handleDownloadPDF = async () => {
    try {
      const fileUri = await generatePDF(results);
      Alert.alert('PDF ready', 'Report generated successfully. The share dialog should open.');
      console.log('PDF at', fileUri);
    } catch (error) {
      console.error(error);
      Alert.alert('Error', 'Failed to generate PDF report');
    }
  };

  const goBack = () => router.push('/');

  if (isLoading) {
    return <SafeAreaView style={styles.container}><Text style={styles.loadingText}>Loading results…</Text></SafeAreaView>;
  }

  if (results.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No results to display</Text>
          <TouchableOpacity style={styles.goBackButton} onPress={goBack}>
            <Text style={styles.goBackButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}><Text style={styles.title}>Prediction Results</Text></View>

        {results.map((r) => (
          <View key={r.id} style={styles.resultCard}>
            <Text style={styles.filename}>File: {r.filename}</Text>
            <View style={styles.contentRow}>
              <Image source={{ uri: r.imageUri }} style={styles.resultImage} />
              <View style={styles.detailsContainer}>
                <Text style={styles.predictedClass}>Predicted Class: {r.predictedClass}</Text>
                <Text style={styles.confidence}>Confidence: {(r.confidence * 100).toFixed(2)}%</Text>
                <ProgressBar progress={r.confidence} color="#059669" style={styles.confidenceBar} />
                {r.isLowConfidence && (
                  <View style={styles.warningContainer}>
                    <Text style={styles.warningText}>⚠ Low confidence: The model is unsure about this prediction.</Text>
                  </View>
                )}
                <Text style={styles.probabilitiesTitle}>Class Probabilities</Text>
                {Object.entries(r.probabilities).map(([k, v]) => (
                  <View key={k} style={styles.probabilityRow}>
                    <Text style={styles.className}>{k}</Text>
                    <ProgressBar progress={v} color={k === r.predictedClass ? '#059669' : '#E5E7EB'} style={styles.probabilityBar} />
                    <Text style={styles.probabilityValue}>{(v * 100).toFixed(2)}%</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>
        ))}

        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.goBackButton} onPress={goBack}>
            <Text style={styles.goBackButtonText}>Go Back</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.downloadButton} onPress={handleDownloadPDF}>
            <Ionicons name="download" size={20} color="white" />
            <Text style={styles.downloadButtonText}>Download PDF</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { padding: 20, alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', color: '#059669' },
  resultCard: { backgroundColor: 'white', marginHorizontal: 16, marginBottom: 16, borderRadius: 12, padding: 16, elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2 },
  filename: { fontSize: 16, fontWeight: 'bold', marginBottom: 12, color: '#1F2937' },
  contentRow: { flexDirection: 'row' },
  resultImage: { width: 120, height: 120, borderRadius: 8, marginRight: 16 },
  detailsContainer: { flex: 1 },
  predictedClass: { fontSize: 16, fontWeight: '600', marginBottom: 4, color: '#1F2937' },
  confidence: { fontSize: 14, color: '#6B7280', marginBottom: 8 },
  confidenceBar: { marginBottom: 12 },
  warningContainer: { backgroundColor: '#FEF3C7', padding: 8, borderRadius: 6, marginBottom: 12, borderWidth: 1, borderColor: '#F59E0B' },
  warningText: { fontSize: 12, color: '#92400E' },
  probabilitiesTitle: { fontSize: 14, fontWeight: 'bold', marginBottom: 8, color: '#1F2937' },
  probabilityRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  className: { width: 60, fontSize: 12, color: '#374151' },
  probabilityBar: { flex: 1, marginHorizontal: 8 },
  probabilityValue: { width: 50, fontSize: 12, color: '#6B7280', textAlign: 'right' },
  actionButtons: { flexDirection: 'row', justifyContent: 'space-around', padding: 20, marginTop: 20 },
  goBackButton: { backgroundColor: '#6B7280', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 8 },
  goBackButtonText: { color: 'white', fontWeight: '600' },
  downloadButton: { backgroundColor: '#059669', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 8, flexDirection: 'row', alignItems: 'center' },
  downloadButtonText: { color: 'white', fontWeight: '600', marginLeft: 8 },
  loadingText: { textAlign: 'center', marginTop: 50, fontSize: 16, color: '#6B7280' },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { fontSize: 18, color: '#6B7280', marginBottom: 20 },
});