import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, FlatList, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { getHistory } from '../../utils/storage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { PredictionResult } from '../../types';

interface HistoryRun { id: string; timestamp: number; items: PredictionResult[] }

export default function HistoryScreen() {
  const [runs, setRuns] = useState<HistoryRun[]>([]);
  const router = useRouter();

  useEffect(() => { (async () => setRuns(await getHistory()))(); }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Classification History</Text>
        {runs.length === 0 ? (
          <Text style={styles.subtitle}>Your previous classification results will appear here</Text>
        ) : (
          <FlatList
            data={runs}
            keyExtractor={(i) => i.id}
            renderItem={({ item }) => (
              <View style={styles.card}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.cardTitle}>{new Date(item.timestamp).toLocaleString()}</Text>
                  <Text style={styles.cardSub}>{item.items.length} item(s)</Text>
                </View>
                <TouchableOpacity
                  style={styles.viewBtn}
                  onPress={async () => {
                    await AsyncStorage.setItem('latestResults', JSON.stringify(item.items));
                    router.push('/results');
                  }}
                >
                  <Ionicons name="open" size={18} color="#fff" />
                  <Text style={styles.viewBtnText}>Open</Text>
                </TouchableOpacity>
              </View>
            )}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  content: { flex: 1, padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#1F2937', marginBottom: 12 },
  subtitle: { fontSize: 16, color: '#6B7280' },
  card: { backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, marginVertical: 8, gap: 12 },
  cardTitle: { fontSize: 16, fontWeight: '600', color: '#111827' },
  cardSub: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  viewBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#059669', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8 },
  viewBtnText: { color: '#fff', fontWeight: '600' },
});