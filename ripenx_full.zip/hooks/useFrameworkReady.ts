import { useEffect } from 'react';

export function useFrameworkReady() {
  useEffect(() => {
    // Placeholder hook – e.g., hide splash or load fonts here
  }, []);
}