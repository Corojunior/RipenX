import React from 'react';
import { View, StyleSheet } from 'react-native';

export const ProgressBar = ({ progress, color = '#059669', style }: { progress: number; color?: string; style?: any }) => {
  const pct = Math.max(0, Math.min(1, progress));
  return (
    <View style={[styles.track, style]}>
      <View style={[styles.fill, { width: `${pct * 100}%`, backgroundColor: color }]} />
    </View>
  );
};

const styles = StyleSheet.create({
  track: { height: 10, backgroundColor: '#E5E7EB', borderRadius: 999, overflow: 'hidden' },
  fill: { height: '100%' },
});