import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export const LogoComponent = () => (
  <View style={styles.wrap}>
    <View style={styles.logoCircle} />
    <Text style={styles.brand}>RipenX</Text>
  </View>
);

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', gap: 12 },
  logoCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#059669' },
  brand: { fontSize: 22, fontWeight: '800', color: '#111827' },
});