# RipenX

## Quick start
```bash
npm i
npm run start
```
- Classify tab → pick images
- Results → view + Download PDF
- History → reopen previous runs
