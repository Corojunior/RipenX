export interface PredictionResult {
  id: string;
  filename: string;
  imageUri: string;
  predictedClass: string;
  confidence: number; // 0..1
  probabilities: { [key: string]: number };
  isLowConfidence: boolean;
}