import AsyncStorage from '@react-native-async-storage/async-storage';
import type { PredictionResult } from '../types';

const HISTORY_KEY = 'history';

export async function saveRunToHistory(items: PredictionResult[]) {
  const prev = await AsyncStorage.getItem(HISTORY_KEY);
  const runs = prev ? JSON.parse(prev) as any[] : [];
  const run = { id: `${Date.now()}`, timestamp: Date.now(), items };
  runs.unshift(run);
  await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(runs.slice(0, 50)));
}

export async function getHistory() {
  const prev = await AsyncStorage.getItem(HISTORY_KEY);
  return prev ? JSON.parse(prev) as any[] : [];
}