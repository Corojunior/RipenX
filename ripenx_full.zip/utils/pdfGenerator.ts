import * as Print from 'expo-print';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as MediaLibrary from 'expo-media-library';
import { Platform } from 'react-native';
import type { PredictionResult } from '../types';

export async function generatePDF(results: PredictionResult[]) {
  const html = buildHtml(results);
  const { uri } = await Print.printToFileAsync({ html });

  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: 'RipenX Report' });
  }

  const dest = FileSystem.documentDirectory! + `RipenX_Report_${Date.now()}.pdf`;
  await FileSystem.copyAsync({ from: uri, to: dest });

  if (Platform.OS === 'android') {
    const { status } = await MediaLibrary.requestPermissionsAsync();
    if (status === 'granted') await MediaLibrary.saveToLibraryAsync(dest);
  }
  return dest;
}

function buildHtml(results: PredictionResult[]) {
  const rows = results.map((r) => `
    <tr>
      <td style="padding:8px;border:1px solid #e5e7eb;">${r.filename}</td>
      <td style="padding:8px;border:1px solid #e5e7eb;">${r.predictedClass}</td>
      <td style="padding:8px;border:1px solid #e5e7eb;">${(r.confidence * 100).toFixed(2)}%</td>
    </tr>`).join('');

  return `
  <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <style>
        body{ font-family: -apple-system,Segoe UI,Roboto,Helvetica,Arial; color:#111827 }
        .title{ color:#059669 }
        table{ border-collapse: collapse; width:100%; }
      </style>
    </head>
    <body>
      <h1 class="title">RipenX — Classification Report</h1>
      <p>Generated at: ${new Date().toLocaleString()}</p>
      <table>
        <thead>
          <tr>
            <th style="text-align:left;padding:8px;border:1px solid #e5e7eb;">Filename</th>
            <th style="text-align:left;padding:8px;border:1px solid #e5e7eb;">Predicted</th>
            <th style="text-align:left;padding:8px;border:1px solid #e5e7eb;">Confidence</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </body>
  </html>`;
}