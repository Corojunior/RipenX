import * as Crypto from 'expo-crypto';
import type { ImagePickerAsset } from 'expo-image-picker';
import type { PredictionResult } from '../types';

const classLabels = ['empty', 'overripe', 'ripe', 'rotten', 'underripe', 'unripe'];

export async function classifyImages(assets: ImagePickerAsset[]): Promise<PredictionResult[]> {
  const out: PredictionResult[] = [];
  for (const a of assets) {
    const id = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, a.uri);
    const seed = id.slice(0, 8);
    const rnd = seeded(seed, 6);
    const probs = softmax(rnd.map((v) => Math.max(0.1, v)));
    const maxIdx = probs.indexOf(Math.max(...probs));
    const predictedClass = classLabels[maxIdx];
    out.push({
      id,
      filename: a.fileName ?? a.uri.split('/').pop() ?? 'image.jpg',
      imageUri: a.uri,
      predictedClass,
      confidence: probs[maxIdx],
      probabilities: Object.fromEntries(classLabels.map((c, i) => [c, probs[i]])),
      isLowConfidence: probs[maxIdx] < 0.55,
    });
  }
  return out;
}

function seeded(s: string, n: number) {
  let x = parseInt(s, 16) || 1;
  const arr: number[] = [];
  for (let i = 0; i < n; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; arr.push(Math.abs(x % 1000) / 1000); }
  return arr;
}
function softmax(vals: number[]) {
  const max = Math.max(...vals);
  const exps = vals.map((v) => Math.exp(v - max));
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map((e) => e / sum);
}